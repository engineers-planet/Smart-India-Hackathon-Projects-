require 'test_helper'

class SignupMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
