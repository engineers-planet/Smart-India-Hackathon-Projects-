require 'test_helper'

class PasswordResetMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
