require 'test_helper'

class ComplaintFeedbackTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
