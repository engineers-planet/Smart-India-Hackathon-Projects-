require 'test_helper'

class ResolvedTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
