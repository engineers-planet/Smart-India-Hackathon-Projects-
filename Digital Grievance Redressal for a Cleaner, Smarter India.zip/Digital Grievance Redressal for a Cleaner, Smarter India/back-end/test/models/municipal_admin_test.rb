require 'test_helper'

class MunicipalAdminTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
