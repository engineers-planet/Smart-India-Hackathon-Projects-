require 'test_helper'

class ActiveComplaintTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
