require 'test_helper'

class MunicipalOfficeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
