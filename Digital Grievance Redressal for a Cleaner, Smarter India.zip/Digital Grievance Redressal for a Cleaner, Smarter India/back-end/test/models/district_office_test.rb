require 'test_helper'

class DistrictOfficeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
