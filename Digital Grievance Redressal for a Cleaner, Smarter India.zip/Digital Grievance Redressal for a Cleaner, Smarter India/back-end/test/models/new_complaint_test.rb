require 'test_helper'

class NewComplaintTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
