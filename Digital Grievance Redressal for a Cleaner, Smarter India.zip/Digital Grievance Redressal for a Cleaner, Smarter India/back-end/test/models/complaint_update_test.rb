require 'test_helper'

class ComplaintUpdateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
