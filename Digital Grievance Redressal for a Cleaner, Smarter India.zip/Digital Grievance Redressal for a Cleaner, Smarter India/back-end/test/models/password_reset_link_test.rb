require 'test_helper'

class PasswordResetLinkTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
