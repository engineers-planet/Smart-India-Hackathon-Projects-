require 'test_helper'

class ComplaintStatusTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
