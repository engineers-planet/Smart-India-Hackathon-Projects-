interface Window {
  AWS?: any;
}
