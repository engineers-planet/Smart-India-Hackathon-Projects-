export class UserDetailX {
  user_name : any;
}
