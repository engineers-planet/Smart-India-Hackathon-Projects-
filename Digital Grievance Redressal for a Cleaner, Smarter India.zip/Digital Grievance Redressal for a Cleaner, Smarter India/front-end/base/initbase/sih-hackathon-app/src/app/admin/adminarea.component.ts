import { Component } from '@angular/core';
import './counter.js';

@Component({
  selector: 'admin-component',
  templateUrl: './adminarea.component.html',
  styleUrls: ['./adminarea.component.css']
})
export class AdminComponent {
  //title = 'app works!';
}
