export interface UserDetailX {
  user_name : string;
  phone_number_verified : boolean;
}
