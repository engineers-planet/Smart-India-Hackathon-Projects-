export class locationX {
  location: string;
}
