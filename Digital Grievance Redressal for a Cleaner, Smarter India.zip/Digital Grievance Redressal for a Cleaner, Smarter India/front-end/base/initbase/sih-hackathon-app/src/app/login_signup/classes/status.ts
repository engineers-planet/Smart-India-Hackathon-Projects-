export class StatusLog{
  
  error_message : any;
}
