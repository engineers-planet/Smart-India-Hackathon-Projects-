export class StatusX {
  // id? : number;
  // status: string;
  // description : string;
  // state : string;
  constructor(
       public id: number,
       public status: string,
       public category : string,
       public image : string
       ){}
}
