export class Status {
  // id? : number;
  // status: string;
  // description : string;
  // state : string;
  constructor(
       public id: number,
       public status: string,
       public description:string,
       public state : string
       ){}
}
