import { Component } from '@angular/core';


@Component({
  selector: 'adminsettings-component',
  templateUrl: './adminsettings.component.html',
  styleUrls: ['./adminsettings.component.css']
})
export class AdminSettingsComponent {
  //title = 'app works!';
}
