export class pieChartDataX {
 news : string;
 old : string;
 comp : string;
  constructor(_news:string,_old:string,_comp:string) {
     // assign local variables to class members
  }
}
// name: string;
// bio: string;
// job: string;
// salary: string;
// url: string
// constructor(_name: string, _bio: string, _job: string, _salary: string, _url: string) {
//   // assign local variables to class members
// }
// }export class User {
