package com.example.pari.usersapp;

import javax.xml.transform.sax.SAXResult;

/**
 * Created by pari on 30-01-2017.
 */

public final class Constants {
    public static final int SUCCESS_RESULT = 0;
    public static final int FAILURE_RESULT = 1;
    public static final String PACKAGE_NAME =
            "com.example.pari.locationaccess";
    public static final String RECEIVER = PACKAGE_NAME + ".RECEIVER";
    public static final String RESULT_DATA_KEY = PACKAGE_NAME +
            ".RESULT_DATA_KEY";
    public static final String LOCATION_DATA_EXTRA = PACKAGE_NAME +
            ".LOCATION_DATA_EXTRA";
    public static final String BUCKET_NAME = "asarcgrs";
    public static final String BUCKET_ACCESS_KEY_ID = "AKIAI4XWYQDCVLFHOW5Q";
    public static final String BUCKET_SECRET_KEY_ID = "Svcp3OnOvkxzXURE1/cg5Tdia6SwSaYa0DxzErH9";
   // public static final String SERVER = "http://192.168.117.60:8000";
   public static final String SERVER = "http://54.169.134.133:80";
  //  public static final String SERVER = "http://192.168.43.93:8000";
}