from django.apps import AppConfig


class RedressalConfig(AppConfig):
    name = 'redressal'
